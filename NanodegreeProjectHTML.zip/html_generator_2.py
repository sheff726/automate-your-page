Python 2.7.9 (default, Dec 10 2014, 12:24:55) [MSC v.1500 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> ================================ RESTART ================================
>>> 

<div class= "concept">
  <div class= "concept-title">
    Lists
  </div>
  <div class= "concept-description">
    Lists can be a sequence of anything even other lists
  </div>
</div> 
<div class= "concept">
  <div class= "concept-title">
    Nested Lists
  </div>
  <div class= "concept-description">
    Lists can have numbers, strings, or other lists inside them and elements can be accessed like strings, with the position number in brackets
  </div>
</div> 
<div class= "concept">
  <div class= "concept-title">
    Mutation
  </div>
  <div class= "concept-description">
    Elements in a list can be changed to a new value with an assignment statement which also changes the value of the list
  </div>
</div> 
<div class= "concept">
  <div class= "concept-title">
    Mutation Issue
  </div>
  <div class= "concept-description">
    If you introduce a new variable and it is assigned the same value as another variable when the value of one is changed the other is as well
  </div>
</div> 
>>> 
